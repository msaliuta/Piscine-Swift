//
//  Article+CoreDataProperties.swift
//  Pods
//
//  Created by Maksym SALIUTA on 2/14/20.
//
//

import Foundation
import CoreData


extension Article {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Article> {
        return NSFetchRequest<Article>(entityName: "Article")
    }

    @NSManaged public var title: String?
    @NSManaged public var content: String?
    @NSManaged public var language: String?
    @NSManaged public var image: Data?
    @NSManaged public var mod_date: Date?
    @NSManaged public var cre_date: Date?

    
}
