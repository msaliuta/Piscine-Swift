//
//  ViewController.swift
//  msaliuta2020
//
//  Created by msaliuta on 02/14/2020.
//  Copyright (c) 2020 msaliuta. All rights reserved.
//

import UIKit
import msaliuta2020

class ViewController: UIViewController {

    let manager = ArticleManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

