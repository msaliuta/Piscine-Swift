//
//  Article+CoreDataClass.swift
//  Pods
//
//  Created by Maksym SALIUTA on 2/14/20.
//
//

import Foundation
import CoreData

@objc(Article)
public class Article: NSManagedObject {

}
