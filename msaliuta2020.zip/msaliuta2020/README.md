# msaliuta2020

[![CI Status](https://img.shields.io/travis/msaliuta/msaliuta2020.svg?style=flat)](https://travis-ci.org/msaliuta/msaliuta2020)
[![Version](https://img.shields.io/cocoapods/v/msaliuta2020.svg?style=flat)](https://cocoapods.org/pods/msaliuta2020)
[![License](https://img.shields.io/cocoapods/l/msaliuta2020.svg?style=flat)](https://cocoapods.org/pods/msaliuta2020)
[![Platform](https://img.shields.io/cocoapods/p/msaliuta2020.svg?style=flat)](https://cocoapods.org/pods/msaliuta2020)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

msaliuta2020 is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'msaliuta2020'
```

## Author

msaliuta, msaliuta@student.unit.ua

## License

msaliuta2020 is available under the MIT license. See the LICENSE file for more info.
